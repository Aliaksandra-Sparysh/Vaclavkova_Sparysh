from PyQt6.QtCore import *
from PyQt6.QtGui import *
from PyQt6.QtWidgets import *
from qpoint3df import *
from random import *
from triangle import *
from edge import *
from math import *


class Draw(QWidget):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.__points = []
        self.__DT = []
        self.__contours = []
        self.__triangles = []

        self.__viewDT = True
        self.__viewContours = True
        self.__viewSlope = True
        self.__viewAspect = False

        self.__terrainMode = "random"

        # Selected color scales
        # Slope modes: "gray", "green_yellow_red", "terrain"
        # Aspect modes: "hsv", "cardinal", "warm_cold"
        self.__slopeColorMode = "gray"
        self.__aspectColorMode = "hsv"

    def mousePressEvent(self, e):
        # Get cursor coordinates
        x = e.position().x()
        y = e.position().y()

        # Define elevation range
        z_min = 200
        z_max = 600

        # Center of the canvas
        cx = self.width() / 2
        cy = self.height() / 2

        # Distance from center
        dx = x - cx
        dy = y - cy
        dist = sqrt(dx * dx + dy * dy)

        # Generate elevation based on selected terrain mode
        if self.__terrainMode == "hill":
            z = 600 - dist

        elif self.__terrainMode == "valley":
            z = 200 + dist

        else:
            # Random terrain
            z = random() * (z_max - z_min) + z_min

        # Create new point
        p = QPoint3DF(x, y, z)

        # Add point to the list
        self.__points.append(p)

        # Repaint
        self.repaint()

    def getSlopeColor(self, slope):
        # Normalize slope from <0, pi/2> to <0, 1>
        t = min(1, max(0, slope / (pi / 2)))

        if self.__slopeColorMode == "gray":
            # Low slope = light, high slope = dark
            v = int(255 * (1 - t))
            return QColor(v, v, v)

        elif self.__slopeColorMode == "green_yellow_red":
            # Low slope = green, medium = yellow, high = red
            if t < 0.5:
                k = t / 0.5
                r = int(255 * k)
                g = 255
                b = 0
            else:
                k = (t - 0.5) / 0.5
                r = 255
                g = int(255 * (1 - k))
                b = 0

            return QColor(r, g, b)

        elif self.__slopeColorMode == "terrain":
            # Low slope = light green, medium = ochre/brown, high = dark brown
            if t < 0.5:
                k = t / 0.5
                r = int(180 + 40 * k)
                g = int(230 - 80 * k)
                b = int(140 - 80 * k)
            else:
                k = (t - 0.5) / 0.5
                r = int(220 - 120 * k)
                g = int(150 - 90 * k)
                b = int(60 - 40 * k)

            return QColor(r, g, b)

        return QColor(200, 200, 200)

    def getAspectColor(self, aspect):
        # Normalize aspect from <-pi, pi> to <0, 1>
        t = (aspect + pi) / (2 * pi)

        if self.__aspectColorMode == "hsv":
            # Continuous circular HSV scale
            hue = int(t * 359)
            return QColor.fromHsv(hue, 150, 255)

        elif self.__aspectColorMode == "cardinal":
            # Four main directions
            angle = (aspect + 2 * pi) % (2 * pi)

            # East
            if angle < pi / 4 or angle >= 7 * pi / 4:
                return QColor(255, 230, 80)

            # North
            elif angle < 3 * pi / 4:
                return QColor(80, 150, 255)

            # West
            elif angle < 5 * pi / 4:
                return QColor(180, 100, 220)

            # South
            else:
                return QColor(255, 120, 60)

        elif self.__aspectColorMode == "warm_cold":
            # Cold northern slopes, warm southern slopes
            angle = (aspect + 2 * pi) % (2 * pi)

            # Coefficient according to southern orientation
            southness = (sin(angle) + 1) / 2

            r = int(80 + 175 * southness)
            g = int(130 + 80 * (1 - abs(southness - 0.5) * 2))
            b = int(255 - 180 * southness)

            return QColor(r, g, b)

        return QColor(200, 200, 200)

    def paintEvent(self, e):
        # Initialize the painter object
        qp = QPainter(self)
        qp.begin(self)

        # Draw only if Slope or Aspect view is enabled
        if self.__viewSlope or self.__viewAspect:
            for tri in self.__triangles:
                if self.__viewSlope:
                    # Visualize slope using selected color scale
                    slope = tri.getSlope()
                    qp.setBrush(self.getSlopeColor(slope))

                elif self.__viewAspect:
                    # Visualize aspect using selected color scale
                    aspect = tri.getAspect()
                    qp.setBrush(self.getAspectColor(aspect))

                # Set transparent border and draw the triangle polygon
                qp.setPen(Qt.GlobalColor.transparent)
                p1, p2, p3 = tri.getVertices()
                poly = QPolygonF([p1, p2, p3])
                qp.drawPolygon(poly)

        # Draw edges if Delaunay Triangulation view is enabled
        if self.__viewDT:
            pen_dt = QPen(Qt.GlobalColor.green, 1)
            qp.setPen(pen_dt)
            qp.setBrush(Qt.BrushStyle.NoBrush)

            for edge in self.__DT:
                qp.drawLine(edge.getStart(), edge.getEnd())

        # Draw lines if Contour view is enabled
        if self.__viewContours:
            # counting
            i = 0

            for c in self.__contours:
                z = c.getStart().z()

                # Highlight index contours (every 100 meters)
                if int(z) % 100 == 0:
                    pen_c = QPen(Qt.GlobalColor.red, 2)
                    draw_label = True
                else:
                    pen_c = QPen(Qt.GlobalColor.gray, 1)
                    draw_label = False

                qp.setPen(pen_c)
                qp.drawLine(c.getStart(), c.getEnd())

                # Label
                if draw_label and i % 7 == 0:
                    x1 = c.getStart().x()
                    y1 = c.getStart().y()
                    x2 = c.getEnd().x()
                    y2 = c.getEnd().y()

                    # Middle of segment
                    xm = (x1 + x2) / 2
                    ym = (y1 + y2) / 2

                    # Label text
                    label = str(int(z))

                    # Offset
                    qp.setPen(Qt.GlobalColor.black)
                    qp.drawText(int(xm + 3), int(ym - 3), label)

                i += 1

        # Draw original points to see the input data
        pen_p = QPen(Qt.GlobalColor.black, 8)
        qp.setPen(pen_p)
        qp.drawPoints(self.__points)

        qp.end()

    def setDT(self, DT):
        # Set Delaunay Triangulation edges
        self.__DT = DT

    def getDT(self):
        # Return list of triangulation edges
        return self.__DT

    def getPoints(self):
        # Return list of input points
        return self.__points

    def setContours(self, contours):
        # Set generated contour lines
        self.__contours = contours

    def setTriangles(self, triangles):
        # Set generated triangle objects
        self.__triangles = triangles

    def getTriangles(self):
        # Return list of triangles
        return self.__triangles

    def setViewDT(self, state):
        # Toggle visibility of triangulation edges
        self.__viewDT = state
        self.repaint()

    def setViewContours(self, state):
        # Toggle visibility of contour lines
        self.__viewContours = state
        self.repaint()

    def setViewSlope(self, state):
        # Enable slope view and disable aspect
        self.__viewSlope = state

        if state:
            self.__viewAspect = False

        self.repaint()

    def setViewExposition(self, state):
        # Enable aspect view and disable slope
        self.__viewAspect = state

        if state:
            self.__viewSlope = False

        self.repaint()

    def setTerrainMode(self, mode):
        self.__terrainMode = mode

    def setSlopeColorMode(self, mode):
        # Change slope color scale
        self.__slopeColorMode = mode
        self.repaint()

    def setAspectColorMode(self, mode):
        # Change aspect color scale
        self.__aspectColorMode = mode
        self.repaint()

    def clearResult(self):
        # Remove calculated data and refresh
        self.__DT.clear()
        self.__contours.clear()
        self.__triangles.clear()
        self.repaint()

    def clearAll(self):
        # Remove points and all calculated data
        self.__points.clear()
        self.clearResult()
