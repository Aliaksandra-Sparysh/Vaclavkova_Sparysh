
from PyQt6 import QtCore, QtGui, QtWidgets
from draw import Draw
from algorithms import *
import struct
import numpy as np
import os

class Ui_MainForm(object):

    def setupUi(self, MainForm):
        # Basic dimensions of the main application window
        self.width = 1043
        self.height = 948
        # Store a reference to the main window
        self.main_form = MainForm
        
        # Set the path to the icons folder relative to this file
        base_dir = os.path.dirname(os.path.abspath(__file__))
        icons_dir = os.path.join(base_dir, "icons")
        
        # Create and configure the main window
        MainForm.setObjectName("MainForm")
        MainForm.resize(self.width, self.height)
        
        # Create the central widget and horizontal layout
        self.centralwidget = QtWidgets.QWidget(parent=MainForm)
        self.centralwidget.setObjectName("centralwidget")
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setObjectName("horizontalLayout")
        
         # Create the drawing canvas where polygons and point are displayed
        self.Canvas = Draw(parent=self.centralwidget)
        self.Canvas.setObjectName("Canvas")
        self.horizontalLayout.addWidget(self.Canvas)
        MainForm.setCentralWidget(self.centralwidget)
        
        # Create individual menu sections
        self.menubar = QtWidgets.QMenuBar(parent=MainForm)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1043, 33))
        self.menubar.setObjectName("menubar")
        self.menuFile = QtWidgets.QMenu(parent=self.menubar)
        self.menuFile.setObjectName("menuFile")
        self.menuInput = QtWidgets.QMenu(parent=self.menubar)
        self.menuInput.setObjectName("menuInput")
        self.menuAnalyze = QtWidgets.QMenu(parent=self.menubar)
        self.menuAnalyze.setObjectName("menuAnalyze")
        MainForm.setMenuBar(self.menubar)
        
        # Create the status bar
        self.statusbar = QtWidgets.QStatusBar(parent=MainForm)
        self.statusbar.setObjectName("statusbar")
        MainForm.setStatusBar(self.statusbar)
        
        # Create the toolbar at the top of the window
        self.toolBar = QtWidgets.QToolBar(parent=MainForm)
        self.toolBar.setObjectName("toolBar")
        MainForm.addToolBar(QtCore.Qt.ToolBarArea.TopToolBarArea, self.toolBar)
        
        # Action for opening a shapefile
        self.actionOpen = QtGui.QAction(parent=MainForm)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(os.path.join(icons_dir, "open_file.png")), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.actionOpen.setIcon(icon)
        self.actionOpen.setObjectName("actionOpen")

        # Action for closing the application
        self.actionExit = QtGui.QAction(parent=MainForm)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(os.path.join(icons_dir, "exit.png")), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.actionExit.setIcon(icon1)
        self.actionExit.setObjectName("actionExit")
        
        # Checkable action used to switch to point movement mode
        self.actionPoint_polygon = QtGui.QAction(parent=MainForm)
        self.actionPoint_polygon.setCheckable(True)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(os.path.join(icons_dir, "pointpol.png")), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.actionPoint_polygon.setIcon(icon2)
        self.actionPoint_polygon.setObjectName("actionPoint_polygon")
        
        # Action for clearing all loaded data and resetting the canvas
        self.actionClear = QtGui.QAction(parent=MainForm)
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap(os.path.join(icons_dir, "clear.png")), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.actionClear.setIcon(icon3)
        self.actionClear.setObjectName("actionClear")
        
        # Action for running the Ray Crossing point-in-polygon algorithm
        self.actionRay_Crossing = QtGui.QAction(parent=MainForm)
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap(os.path.join(icons_dir, "ray.png")), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.actionRay_Crossing.setIcon(icon4)
        self.actionRay_Crossing.setObjectName("actionRay_Crossing")
        
        # Action for running the Winding Number point-in-polygon algorithm
        self.actionWinding_Number = QtGui.QAction(parent=MainForm)
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap(os.path.join(icons_dir, "winding.png")), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.actionWinding_Number.setIcon(icon5)
        self.actionWinding_Number.setObjectName("actionWinding_Number")
        
        # Add actions to the File and Input menu
        self.menuFile.addAction(self.actionOpen)
        self.menuFile.addSeparator()
        self.menuFile.addAction(self.actionExit)
        self.menuInput.addAction(self.actionPoint_polygon)
        self.menuInput.addSeparator()
        self.menuInput.addAction(self.actionClear)
        
        # Add actions to the Input and analyze menu
        self.menuAnalyze.addAction(self.actionRay_Crossing)
        self.menuAnalyze.addAction(self.actionWinding_Number)
        self.menubar.addAction(self.menuFile.menuAction())
        self.menubar.addAction(self.menuInput.menuAction())
        self.menubar.addAction(self.menuAnalyze.menuAction())
        
        # Add actions to the toolbar
        self.toolBar.addAction(self.actionOpen)
        self.toolBar.addSeparator()
        self.toolBar.addAction(self.actionRay_Crossing)
        self.toolBar.addAction(self.actionWinding_Number)
        self.toolBar.addSeparator()
        self.toolBar.addAction(self.actionPoint_polygon)
        self.toolBar.addSeparator()
        self.toolBar.addAction(self.actionClear)

        # Set labels, window titles, and tooltips
        self.retranslateUi(MainForm)
        QtCore.QMetaObject.connectSlotsByName(MainForm)
        
        #Connect signals and slots
        self.actionPoint_polygon.triggered.connect(self.changeStatusClick)
        # Automatically connect slots by object names
        self.actionClear.triggered.connect(self.clearClick)
        self.actionOpen.triggered.connect(self.openFileClick)
        self.actionRay_Crossing.triggered.connect(self.analyzeRC)
        self.actionWinding_Number.triggered.connect(self.analyzeWN)
        
    def analyzeRC(self):
        # Start analysis using the Ray Crossing method
        self.analyzePointAndPositionClick("RC")

    def analyzeWN(self):
        # Start analysis using the Winding Number method
        self.analyzePointAndPositionClick("WN")

    def openFileClick(self):
          # Open file dialog to select a Shapefile
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(self.main_form, "Select a file to open","","Shapefiles (*.shp);;All Files (*)")
        if file_path:
            print(f"Successfully selected: {file_path}")
            # Load polygon geometries from the selected file
            polygons = self.getPolygonsFromSHP(file_path)

            if polygons:
                self.Canvas.drawPolygons(polygons)

    # Normalize polygon coordinates to fit the canvas
    def normalizeData(self, polygons_list, canvas_width, canvas_height, margin=50):
        # If there are no polygons to normalize, return an empty list
        if not polygons_list:
            return []

        #Merge all polygons to find global min/max boundaries
        # polygons_list is List[List[np.array]] (nested list for each record)
        all_rings = [ring for poly in polygons_list for ring in poly]
        all_points = np.vstack(all_rings)
        # Find the minimum and maximum coordinates of the whole dataset
        min_vals = np.min(all_points, axis=0)
        max_vals = np.max(all_points, axis=0)
        
        #Calculate real-world data dimensions
        data_width = max_vals[0] - min_vals[0]
        data_height = max_vals[1] - min_vals[1]
        
        #Avoid division by zero
        if data_width == 0: data_width = 1
        if data_height == 0: data_height = 1
        
        #Calculate scale to fit data within canvas margins
        usable_width = canvas_width - (margin * 2)
        usable_height = canvas_height - (margin * 2)
        scale = min(usable_width / data_width, usable_height / data_height) * 0.9
        
        #Calculate scaled dimensions for map centering
        scaled_width = data_width * scale
        scaled_height = data_height * scale
        
        #Calculate offsets to center the map on canvas
        offset_x = (canvas_width - scaled_width + margin) / 2
        offset_y = (canvas_height - scaled_height + margin) / 2

        #Transform and normalize each polygon
        normalized_polygons = []
        for poly in polygons_list:
            normalized_poly = []
            
            for coords in poly:
                # Create an empty array with the same shape as the original coordinates
                norm_coords = np.zeros_like(coords, dtype=float)
                
                # Normalize x coordinates- shift them to start at zero, scale them, and move them by offset
                norm_coords[:, 0] = (coords[:, 0] - min_vals[0]) * scale + offset_x
                # Normalize y coordinates- flip them because screen coordinates grow downward
                norm_coords[:, 1] = canvas_height - offset_y - ((coords[:, 1] - min_vals[1]) * scale)
                
                # Add the normalized ring to the current polygon
                normalized_poly.append(norm_coords)
            
            # Add the normalized polygon to the final list
            normalized_polygons.append(normalized_poly)
            
        return normalized_polygons

    def show_error_popup(self, title, message):
        mb = QtWidgets.QMessageBox(self.main_form)
        mb.setWindowTitle(title)
        
        #Set results
        mb.setText(message)            
        #Show message box
        mb.exec()


    def changeStatusClick(self):
        #User defined slot, change source
        self.Canvas.changeStatus()
        
    def is_clockwise(self, points):
        # Compute the orientation of a polygon ring using a signed area-like sum
        total_sum = 0
        # Iterate through all edges of the polygon
        for i in range(len(points)):
            p1 = points[i]
            p2 = points[(i + 1) % len(points)]
            # Add contribution of the current edge to the orientation sum
            total_sum += (p2[0] - p1[0]) * (p2[1] + p1[1])
        
        return total_sum > 0
    
    def getPolygonsFromSHP(self, file_path):
        # List for storing all loaded polygons from the shapefile
        polygons = []
        try:
            with open(file_path, "rb") as f:
                # Read the fixed 100-byte shapefile header
                header = f.read(100)
                shape_type, = struct.unpack("<i", header[32:36])
                
                # Check whether the shapefile contains polygon geometries
                # 5 = Polygon, 15 = PolygonZ, 25 = PolygonM
                if shape_type not in [5, 15, 25]:
                    self.show_error_popup("Data Error", f"This Shapefile does not contain polygon geometries! (Detected type {shape_type})")
                    return None
                
                # Read all shape records one by one
                while True:
                    record_header = f.read(8)
                    
                    # Stop reading when the end of the file is reached
                    if not record_header or len(record_header) < 8:
                        break 
                    
                    # The record header contains the record number and content length in big-endian format
                    _, content_length = struct.unpack(">ii", record_header)
                    # Content length is stored in 16-bit words, so it must be multiplied by 2 to get bytes
                    content_bytes = content_length * 2
                    # Read the full content of the current record
                    record_content = f.read(content_bytes)
                    
                     # Read the shape type of the current record
                    rec_shape_type, = struct.unpack("<i", record_content[0:4])
                    # Skip invalid or empty records
                    if rec_shape_type not in [5, 15, 25]:
                        continue

                    num_parts, num_points = struct.unpack("<ii", record_content[36:44])

                    #Skip Null shape
                    if num_parts <= 0 or num_points <= 0:
                        continue
                    
                    # Read the starting index of each polygon part
                    parts_indices = list(struct.unpack(f"<{num_parts}i", record_content[44:44 + num_parts * 4]))
                    # Add the total number of points as the ending index of the last part
                    parts_indices.append(num_points)
                    
                    points_start_index = 44 + (num_parts * 4)
                    
                    # We iterate through the individual parts of the polygon
                    record_polygons = []
                    for p in range(num_parts):
                        part_points = []
                        
                        # Get the start and end point index of the current part
                        start_pt = parts_indices[p]
                        end_pt = parts_indices[p+1]
                    
                        # Loading points for a specific part
                        for i in range(start_pt, end_pt):
                            start = points_start_index + (i * 16)
                            x, y = struct.unpack("<dd", record_content[start:start+16])
                            part_points.append([x, y])
                        
                        #Add the loaded points to the list of parts of this polygo
                        if len(part_points) > 0:
                            record_polygons.append(np.array(part_points))
                    
                    if record_polygons:
                        polygons.append(record_polygons)
                    
            print("Successfully loaded polygons")
            
            # If no valid shapes were found in the file, terminate the process
            if len(polygons) == 0:
                self.show_error_popup("Data Loading Error")
                return None
            
            # Normalize polygon coordinates so they fit into the application canvas
            normalized_polygons = self.normalizeData(polygons, self.main_form.width(), self.main_form.height())
            return normalized_polygons

        except Exception as e:
            self.show_error_popup("Data Loading Error", f"Failed to load Shapefile.\nError: {str(e)}")
            return None
        
    def clearClick(self):
        #User defined slot, clear data
        self.Canvas.clearData()    
        

    def analyzePointAndPositionClick(self, method):
         # Analyze position of a point relative to all polygons
        q = self.Canvas.getQ()
        pols = self.Canvas.getPol()
        
        if q.x() < 0 or len(pols) == 0:  
            mb = QtWidgets.QMessageBox()
            mb.setWindowTitle("Error")
            mb.setText("Please load polygons and set a point first!")
            mb.exec()
            return

        a = Algorithms()
        
        # Our lists and flags for storing the state
        found_polygons_in = []
        found_polygons_vert = []
        found_polygons_edge = []
        candidate_boxes = []
        
        # Iterate through all polygons on the map
        for pol in pols:
            box = a.createMinMaxBox(pol)
            # First perform a quick min-max box test
            if not a.pointInMinMaxBox(q, box):
                continue
            # Store the box for visualization
            candidate_boxes.append(box)
            
            if method == "WN":
                result = a.getPointPolygonPositionWinding(q, pol)
            else:
                result = a.getPointPolygonPositionRC(q, pol)
            
            #Evaluate results from algorithms.py
            #Inside
            if result == 1:       
                found_polygons_in.append(pol)
            #Boundary
            elif result == -1:    
                found_polygons_edge.append(pol)
            #Vertex
            elif result == -2:   
                found_polygons_vert.append(pol)
        self.Canvas.setMinMaxBoxes(candidate_boxes)
        
        # Prepare the popup window
        mb = QtWidgets.QMessageBox()
        mb.setWindowTitle('Point and polygon position')
        # Decision logic for selecting the correct message - vertex has priority over edge
        
        
        # Decision logic for selecting the correct message - vertex has priority over edge and inside
        if len(found_polygons_vert) > 0:
            # The point lies on one or more polygon vertices
            mb.setText(f"Point is exactly on a VERTEX shared by {len(found_polygons_vert)} polygon(s)")
            self.Canvas.setHighlightedPolygons(found_polygons_vert)

        elif len(found_polygons_edge) > 0:
            # The point lies on one or more polygon edges
            mb.setText(f"Point is on a BOUNDARY shared by {len(found_polygons_edge)} polygon(s)")
            self.Canvas.setHighlightedPolygons(found_polygons_edge)

        elif len(found_polygons_in) > 1:
            # The point is inside more than one polygon, which means the polygons overlap
            mb.setText(f"Point is INSIDE {len(found_polygons_in)} overlapping polygons")
            self.Canvas.setHighlightedPolygons(found_polygons_in)

        elif len(found_polygons_in) == 1:
            # The point is inside exactly one polygon
            mb.setText("Point is INSIDE the polygon")
            self.Canvas.setHighlightedPolygons(found_polygons_in)

        else:
            # The point is not inside any polygon and does not lie on any boundary
            mb.setText("Point is OUTSIDE all polygons")
            self.Canvas.setHighlightedPolygons([])
            
        # Refresh the canvas and display the window
        QtWidgets.QApplication.processEvents()
        # Display the result message box
        mb.exec()
    

    def retranslateUi(self, MainForm):
        # Helper function used by Qt for translating UI text
        _translate = QtCore.QCoreApplication.translate
        # Set the main window title
        MainForm.setWindowTitle(_translate("MainForm", "Analyze point and polygon position"))
        # Set menu titles
        self.menuFile.setTitle(_translate("MainForm", "File"))
        self.menuInput.setTitle(_translate("MainForm", "Input"))
        self.menuAnalyze.setTitle(_translate("MainForm", "Analyze"))
        # Set toolbar title
        self.toolBar.setWindowTitle(_translate("MainForm", "toolBar"))
        self.actionOpen.setText(_translate("MainForm", "Open"))
        self.actionOpen.setToolTip(_translate("MainForm", "Open file"))
        self.actionExit.setText(_translate("MainForm", "Exit"))
        self.actionExit.setToolTip(_translate("MainForm", "Close application"))
        self.actionPoint_polygon.setText(_translate("MainForm", "Point"))
        self.actionPoint_polygon.setToolTip(_translate("MainForm", "Allow moving point"))
        self.actionClear.setText(_translate("MainForm", "Clear"))
        self.actionClear.setToolTip(_translate("MainForm", "Clear data"))
        self.actionRay_Crossing.setText(_translate("MainForm", "Ray Crossing"))
        self.actionRay_Crossing.setToolTip(_translate("MainForm", "Analyze point and polygon position using Ray Crossing algorithm"))
        self.actionWinding_Number.setText(_translate("MainForm", "Winding Number"))
        self.actionWinding_Number.setToolTip(_translate("MainForm", "Analyze point and polygon position using Winding Number algorithm"))



if __name__ == "__main__":
    # Import sys to access command-line arguments and exit the application correctly
    import sys
    # Create the Qt application object
    app = QtWidgets.QApplication(sys.argv)
    # Create the main application window
    MainForm = QtWidgets.QMainWindow()
    # Create and set up the user interface
    ui = Ui_MainForm()
    ui.setupUi(MainForm)
    # Show the main window on the screen
    MainForm.show()
    sys.exit(app.exec())
    
    
