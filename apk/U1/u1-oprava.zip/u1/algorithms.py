
from PyQt6.QtCore import *
from PyQt6.QtGui import *
from PyQt6.QtWidgets import *
from math import *


class Algorithms:
    def __init__(self):
        # Tolerance used to slightly expand the bounding box
        self.tolerance = 5
    def createMinMaxBox(self, poly_rings: list[QPolygonF]):
        # Initialize extreme values for bounding box computation
        min_x = float("inf")
        max_x = float("-inf")
        min_y = float("inf")
        max_y = float("-inf")
        
        # Iterate through all polygon rings and their vertices
        for ring in poly_rings:
            for p in ring:
                # Update minimum and maximum x coordinates
                if p.x() < min_x:
                    min_x = p.x()
                if p.x() > max_x:
                    max_x = p.x()
                # Update minimum and maximum y coordinates
                if p.y() < min_y:
                    min_y = p.y()
                if p.y() > max_y:
                    max_y = p.y()
                    
         # Create and return bounding box
        return QRectF(
            QPointF(min_x - self.tolerance, min_y - self.tolerance),
            QPointF(max_x + self.tolerance, max_y + self.tolerance)
        )

    def pointInMinMaxBox(self, q: QPointF, box: QRectF):
        # Check whether the query point lies inside the given bounding box
        return box.left() <= q.x() <= box.right() and box.top() <= q.y() <= box.bottom()
    
    def getPointPolygonPositionRC(self, q:QPointF, poly_rings:list[QPolygonF]):
        # Analyze point and polygon position using Ray Crossing algorithm
        #  1 = point is inside the polygon, 0 = point is outside, -1 = point is on edge, -2 = point is on a vertex

        # Right and left intersection counters
        k = 0
        kl = 0

        # Process polygon parts
        for pol in poly_rings:
            n = len(pol)
            for i in range(n):
                # Start point of the edge relative to q
                xi = pol[i].x() - q.x()
                yi = pol[i].y() - q.y()

                # End point of the edge relative to q
                xi1 = pol[(i + 1) % n].x() - q.x()
                yi1 = pol[(i + 1) % n].y() - q.y()

                # Check if q is on a vertex
                if sqrt(xi**2 + yi**2) <= self.tolerance:
                    return -2

                # Find suitable segment crossing the horizontal line through q
                if ((yi1 > 0) and (yi <= 0)) or ((yi > 0) and (yi1 <= 0)):
                    # Compute intersection with horizontal line through q
                    xm = (xi1 * yi - xi * yi1) / (yi1 - yi)

                    # Intersection is close to q, so q is on the edge
                    if abs(xm) <= self.tolerance:
                        return -1

                    # Count right and left intersections
                    if xm > 0:
                        k += 1
                    elif xm < 0:
                        kl += 1

        # If parity of right and left intersections differs, point is on boundary
        if (k % 2) != (kl % 2):
            return -1

        # Point is inside the polygon if number of right intersections is odd
        if k % 2 == 1:
            return 1

        # Point is outside the polygon
        return 0

    def getPointPolygonPositionWinding(self, q, poly_rings:list[QPolygonF]):
        # Analyze point and polygon position using Winding Number algorithm
        #  1 = point is inside the polygon, 0 = point is outside, -1 = point is on edge, -2 = point is on a vertex

        total_angle = 0.0
        eps = 1.0e-7

        # Process polygon parts
        for pol in poly_rings:
            n = len(pol)
            for i in range(n):
                point1 = pol[i]
                point2 = pol[(i + 1) % n]

                # Vectors from point q to edge vertices
                v1_x = point1.x() - q.x()
                v1_y = point1.y() - q.y()
                v2_x = point2.x() - q.x()
                v2_y = point2.y() - q.y()

                # Vector lengths
                dist1 = sqrt(v1_x**2 + v1_y**2)
                dist2 = sqrt(v2_x**2 + v2_y**2)

                # If distance is smaller than tolerance, q is on a vertex
                if dist1 <= self.tolerance or dist2 <= self.tolerance:
                    return -2

                # Dot product calculates angle size, cross product determines orientation
                dot_product = (v1_x * v2_x) + (v1_y * v2_y)
                cross_product = (v1_x * v2_y) - (v1_y * v2_x)

                # Calculate angle and fix possible floating-point errors
                val = dot_product / (dist1 * dist2)
                if val > 1.0:
                    val = 1.0
                if val < -1.0:
                    val = -1.0
                angle = acos(val)

                # If there is no turn and the angle is 180 degrees, q is on the edge
                if abs(cross_product) < eps and abs(angle - pi) < eps:
                    return -1

                # Add or subtract angle according to orientation
                if cross_product > 0:
                    total_angle += angle
                elif cross_product < 0:
                    total_angle -= angle

        # If total angle is 360 degrees, point is inside the polygon
        if abs(abs(total_angle) - 2 * pi) < eps:
            return 1

        # Point is outside the polygon
        return 0
