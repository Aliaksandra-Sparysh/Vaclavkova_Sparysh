from numpy import *
from pyproj import *
from matplotlib.pyplot import *

def project(proj_name, R_z, lat, lon, lat0, lon0=0):
    # Create new projection given by proj_name
    my_proj = Proj(proj=proj_name, R=R_z, lat_1 = lat0, lon_0 = lon0)

    # Project point calculation
    [X,Y] = my_proj(lon, lat)

    #Distortions
    dist = my_proj.get_factors(lon, lat)
    a = dist.tissot_semimajor
    b = dist.tissot_semiminor

    return X, Y, a, b 

def graticule(lat_min, lon_min, lat_max, lon_max, Dlat, Dlon, dlat, dlon, R, lat0, proj_name, lon0):
    #Create graticule of the given map projection
    #Create meridians
    lat_mer = arange(lat_min, lat_max + dlat/2, dlat)
    lon_mer = arange(lon_min, lon_max + Dlon/2, Dlon)
    
    #Create parallels
    lat_par = arange(lat_min, lat_max + Dlat/2, Dlat)
    lon_par = arange(lon_min, lon_max + dlon/2, dlon)

    #Create meshgrid
    lat_merg, lon_merg = meshgrid(lat_mer, lon_mer)
    lon_parg, lat_parg = meshgrid(lon_par, lat_par)
    
    #Project meridians
    mer_proj = project(proj_name, R, lat_merg, lon_merg, lat0, lon0)

    #Project parallels
    par_proj = project(proj_name, R, lat_parg, lon_parg, lat0, lon0)
    
    return mer_proj, par_proj   

#Define projection
proj_name = "sinu"
#proj_name = "bonne"
#proj_name = "eck5"
#proj_name = "wintri"
#proj_name = "aitoff"
#proj_name = "laea"
#proj_name = "guyou"
#proj_name = "loxim"



R = 6380000
lat0 = 65
lon0 = -10

#Define projection grid
lat_min = 50
lat_max = 84
lon_min = -80
lon_max = 60
Dlat = 10
Dlon = 10
dlat = 0.1 * Dlat
dlon = 0.1 * Dlon
nlat = 180
nlon = 100


#Create intervals
lat = linspace(lat_min, lat_max, nlat)
lon = linspace(lon_min, lon_max, nlon)

#Create meshgrid
latg, long = meshgrid(lat, lon)

#Project meshgrid
X, Y, a, b = project(proj_name, R, latg, long, lat0, lon0)

#Airy local
h2_a = 0.5*((a-1)**2+(b-1)**2)

#Complex local
h2_c = 0.5*(abs(a-1)+abs(b-1)) + a/b - 1

#Airy global
H2_a = nanmean(h2_a)

#Complex global
H2_c = nanmean(h2_c)

#Airy weighted global
w = cos(latg * pi /180)
H2_aw = nansum(w*h2_a)/nansum(w)

#Complex weighted global
H2_cw = nansum(w*h2_c)/nansum(w) 

print(H2_a, H2_aw, H2_c, H2_cw)

#Draw countries
countries = ["fin", "isl", "nor", "swe", "grl", "dnk"]

for i in countries:
    try:
        cont_data = loadtxt(f"continents_points/{i}.txt")
        #Project points
        Xc, Yc, _, _ = project(proj_name, R, cont_data[:, 0], cont_data[:, 1], lat0, lon0)
        #Draw plot
        plot(Xc, Yc, color='teal', linewidth=1.5)
    except:
        print("No points.")


#Create meridians and parallels
mer_proj, par_proj = graticule(lat_min, lon_min, lat_max, lon_max, Dlat, Dlon, dlat, dlon, R, lat0, proj_name, lon0)

#Extract coordinates
Xm = mer_proj[0]
Ym = mer_proj[1]

Xp = par_proj[0]
Yp = par_proj[1]

#Plot meridians and parallels
plot(transpose(Xm), transpose(Ym), color = 'black', linewidth = 0.5)
plot(transpose(Xp), transpose(Yp), color = 'black', linewidth = 0.5)


#Variable map scale
S = 100000000
Sv = S/a

#Create contour lines
dS = arange(20000000, 200000000, 5000000)
contours = contour(X, Y, Sv, levels = dS, colors = 'deeppink')

#Create contour labels
labels = clabel(contours, inline=True, inline_spacing=-20, fmt='  %1.0f  ', fontsize=5)

for txt in labels:
    txt.set_bbox(dict(facecolor='white', edgecolor='none', pad=0.2))


axis('equal')

show()