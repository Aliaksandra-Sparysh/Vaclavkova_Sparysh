from numpy import *
from pyproj import *
from matplotlib.pyplot import *

def project(proj_name, R_z, lat, lon, lat0, lon0=0):
    # Create new projection given by proj_name
    my_proj = Proj(proj=proj_name, R=R_z, lat_1 = lat0, lon_0 = lon0)

    # Project point calculation
    [X,Y] = my_proj(lon, lat)

    #Distortions
    dist = my_proj.get_factors(lon, lat)
    a = dist.tissot_semimajor
    b = dist.tissot_semiminor

    return X, Y, a, b 

def graticule(lat_min, lon_min, lat_max, lon_max, Dlat, Dlon, dlat, dlon, R, lat0, proj_name, lon0):
    #Create graticule of the given map projection
    #Create meridians
    lat_mer = arange(lat_min, lat_max + dlat/2, dlat)
    lon_mer = arange(lon_min, lon_max + Dlon/2, Dlon)
    
    #Create parallels
    lat_par = arange(lat_min, lat_max + Dlat/2, Dlat)
    lon_par = arange(lon_min, lon_max + dlon/2, dlon)

    #Create meshgrid
    lat_merg, lon_merg = meshgrid(lat_mer, lon_mer)
    lon_parg, lat_parg = meshgrid(lon_par, lat_par)
    
    #Project meridians
    mer_proj = project(proj_name, R, lat_merg, lon_merg, lat0, lon0)

    #Project parallels
    par_proj = project(proj_name, R, lat_parg, lon_parg, lat0, lon0)
    
    return mer_proj, par_proj   

#Define projection
proj_name = "sinu"
#proj_name = "bonne"
#proj_name = "eck5"
#proj_name = "wintri"
#proj_name = "aitoff"
#proj_name = "laea"
#proj_name = "guyou"
#proj_name = "loxim"


R = 6380000
lat0 = 65
lon0 = -10

#Define projection grid
lat_min = 50
lat_max = 84
lon_min = -80
lon_max = 60
Dlat = 10
Dlon = 10
dlat = 0.1 * Dlat
dlon = 0.1 * Dlon
nlat = 180
nlon = 100


#Create intervals
lat = linspace(lat_min, lat_max, nlat)
lon = linspace(lon_min, lon_max, nlon)

#Create meshgrid
latg, long = meshgrid(lat, lon)

#Project meshgrid
X, Y, a, b = project(proj_name, R, latg, long, lat0, lon0)

#Airy local
h2_a = 0.5*((a-1)**2+(b-1)**2)

#Complex local
h2_c = 0.5*(abs(a-1)+abs(b-1)) + a/b - 1

#Airy global
H2_a = nanmean(h2_a)

#Complex global
H2_c = nanmean(h2_c)

#Airy weighted global
w = cos(latg * pi /180)
H2_aw = nansum(w*h2_a)/nansum(w)

#Complex weighted global
H2_cw = nansum(w*h2_c)/nansum(w) 

print(H2_a, H2_aw, H2_c, H2_cw)


#Draw Finland
cont_fin = loadtxt("continents_points/fin.txt")
X_fin, Y_fin, a_fin, b_fin = project(proj_name, R, cont_fin[:, 0], cont_fin[:, 1], lat0, lon0)
plot(X_fin, Y_fin, color='teal', linewidth=1.5)

#Draw Island
cont_isl = loadtxt("continents_points/isl.txt")
X_isl, Y_isl, a_isl, b_isl = project(proj_name, R, cont_isl[:, 0], cont_isl[:, 1], lat0, lon0)
plot(X_isl, Y_isl, color='teal', linewidth=1.5)

#Draw Norway
cont_nor = loadtxt("continents_points/nor.txt")
X_nor, Y_nor, a_nor, b_nor = project(proj_name, R, cont_nor[:, 0], cont_nor[:, 1], lat0, lon0)
plot(X_nor, Y_nor, color='teal', linewidth=1.5)

#Draw Sweden
cont_swe = loadtxt("continents_points/swe.txt")
X_swe, Y_swe, a_swe, b_swe = project(proj_name, R, cont_swe[:, 0], cont_swe[:, 1], lat0, lon0)
plot(X_swe, Y_swe, color='teal', linewidth=1.5)

#Draw Greenland
cont_grl = loadtxt("continents_points/grl.txt")
X_grl, Y_grl, a_grl, b_grl = project(proj_name, R, cont_grl[:, 0], cont_grl[:, 1], lat0, lon0)
plot(X_grl, Y_grl, color='teal', linewidth=1.5)

#Draw Denmark
cont_dnk = loadtxt("continents_points/dnk.txt")
X_dnk, Y_dnk, a_dnk, b_dnk = project(proj_name, R, cont_dnk[:, 0], cont_dnk[:, 1], lat0, lon0)
plot(X_dnk, Y_dnk, color='teal', linewidth=1.5)


#Create meridians and parallels
mer_proj, par_proj = graticule(lat_min, lon_min, lat_max, lon_max, Dlat, Dlon, dlat, dlon, R, lat0, proj_name, lon0)

#Extract coordinates
Xm = mer_proj[0]
Ym = mer_proj[1]

Xp = par_proj[0]
Yp = par_proj[1]

#Plot meridians and parallels
plot(transpose(Xm), transpose(Ym), color = 'black', linewidth = 0.5)
plot(transpose(Xp), transpose(Yp), color = 'black', linewidth = 0.5)


#Variable map scale
S = 100000000
Sv = S/a

#Create contour lines
dS = arange(20000000, 200000000, 5000000)
contours = contour(X, Y, Sv, levels = dS, colors = 'deeppink')

#Create contour labels
labels = clabel(contours, inline=True, inline_spacing=-20, fmt='  %1.0f  ', fontsize=5)

for txt in labels:
    txt.set_bbox(dict(facecolor='white', edgecolor='none', pad=0.2))


axis('equal')

show()